TeamPulse Brand Kit
===================

Contents
--------
- brand-overview.txt: Elevator pitch, product positioning, and messaging pillars.
- logo-usage.txt: Guidance for logo usage on light and dark backgrounds.
- color-palette.txt: Primary and secondary color values.

For additional assets (PNG, SVG), contact partners@incumate.io.
